---
title: Person vcard
categories:
  - People
tags:
  - human
  - individual
  - avatar
  - user
  - account
---
