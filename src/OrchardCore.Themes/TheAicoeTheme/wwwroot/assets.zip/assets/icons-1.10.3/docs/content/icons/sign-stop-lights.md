---
title: Sign stop lights
categories:
  - Transportation
tags:
  - "stop sign"
  - intersection
  - road
  - driving
---
