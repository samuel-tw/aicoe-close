---
title: Wifi off
categories:
  - Communications
tags:
  - internet
  - network
  - wireless
---
