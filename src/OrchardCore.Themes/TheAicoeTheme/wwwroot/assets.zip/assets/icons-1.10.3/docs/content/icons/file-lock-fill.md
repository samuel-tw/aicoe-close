---
title: File lock fill
categories:
  - Files and folders
tags:
  - lock
  - private
  - secure
---
