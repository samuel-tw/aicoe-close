---
title: Subscript
categories:
  - Typography
tags:
  - text
  - type
---
