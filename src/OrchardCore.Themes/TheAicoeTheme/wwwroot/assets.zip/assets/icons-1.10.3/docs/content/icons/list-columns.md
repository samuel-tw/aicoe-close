---
title: List columns
categories:
  - Typography
tags:
  - text
  - type
  - alignment
---
