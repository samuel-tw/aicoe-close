---
title: Filetype cs
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
  - code
---
