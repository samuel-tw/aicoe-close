---
title: Patch minus fill
categories:
  - Badges
tags:
aliases:
  - /icons/patch-minus-fll/
---
