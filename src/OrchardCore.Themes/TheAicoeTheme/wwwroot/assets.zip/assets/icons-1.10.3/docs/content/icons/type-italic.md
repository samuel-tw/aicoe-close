---
title: Type italic
categories:
  - Typography
tags:
  - text
  - type
---
