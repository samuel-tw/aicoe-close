---
title: Triangle fill
categories:
  - Shapes
tags:
  - shape
---
