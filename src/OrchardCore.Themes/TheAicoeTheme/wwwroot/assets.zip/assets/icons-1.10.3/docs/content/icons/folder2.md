---
title: Folder2
categories:
  - Files and folders
tags:
  - directory
---
