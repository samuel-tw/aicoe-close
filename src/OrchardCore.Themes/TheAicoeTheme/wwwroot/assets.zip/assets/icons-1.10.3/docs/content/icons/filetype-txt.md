---
title: Filetype txt
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
---
