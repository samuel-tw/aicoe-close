---
title: Plug fill
categories:
  - Real world
tags:
  - power
  - outlet
---
