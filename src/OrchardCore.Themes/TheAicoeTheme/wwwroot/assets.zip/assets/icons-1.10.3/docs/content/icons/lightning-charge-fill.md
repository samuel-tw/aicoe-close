---
title: Lightning charge fill
categories:
  - Miscellaneous
tags:
  - weather
  - storm
  - thunder
  - bolt
---
