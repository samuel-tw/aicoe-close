---
title: Filetype pdf
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
---
