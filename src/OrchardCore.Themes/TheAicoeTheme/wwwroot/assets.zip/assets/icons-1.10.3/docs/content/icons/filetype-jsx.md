---
title: Filetype jsx
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
  - code
  - javascript
  - react
---
