---
title: X octagon fill
categories:
  - Alerts, warnings, and signs
tags:
  - x
  - delete
  - remove
  - reset
  - clear
  - cancel
  - close
  - exit
---
