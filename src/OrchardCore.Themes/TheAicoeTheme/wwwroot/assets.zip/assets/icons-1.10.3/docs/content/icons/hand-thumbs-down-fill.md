---
title: Hand thumbs down fill
categories:
  - Hands
tags:
  - hand
  - pointer
  - thumbs-down
  - "-1"
---
