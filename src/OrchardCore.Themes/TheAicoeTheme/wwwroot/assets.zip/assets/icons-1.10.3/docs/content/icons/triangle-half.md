---
title: Triangle half fill
categories:
  - Shapes
tags:
  - shape
---
