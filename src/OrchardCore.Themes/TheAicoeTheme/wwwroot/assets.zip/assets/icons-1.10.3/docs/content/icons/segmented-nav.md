---
title: Segmented nav
categories:
  - Controls
tags:
  - nav
  - tabs
  - tabbed
  - app
  - ui
---
