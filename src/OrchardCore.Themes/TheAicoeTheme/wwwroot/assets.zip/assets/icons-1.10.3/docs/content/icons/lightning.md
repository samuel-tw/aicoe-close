---
title: Lightning
categories:
  - Weather
tags:
  - storm
  - thunder
  - bolt
---
