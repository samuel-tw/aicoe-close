---
title: Icon Sprite
description: Use Bootstrap Icons as an SVG sprite, built from our SVGs and easily customized with CSS.
layout: sprite
---
