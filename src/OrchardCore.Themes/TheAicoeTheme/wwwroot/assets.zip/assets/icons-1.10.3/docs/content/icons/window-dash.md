---
title: Window dash
categories:
  - Apps
tags:
  - application
  - desktop
  - app
---
