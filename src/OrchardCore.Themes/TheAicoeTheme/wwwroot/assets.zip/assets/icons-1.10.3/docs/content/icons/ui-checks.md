---
title: UI checks
categories:
  - Controls
tags:
  - checkbox
  - form
---
