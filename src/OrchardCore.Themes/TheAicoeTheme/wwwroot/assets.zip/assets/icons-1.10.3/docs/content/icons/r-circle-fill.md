---
title: R circle fill
categories:
  - Shapes
tags:
  - registered
  - trademark
---
