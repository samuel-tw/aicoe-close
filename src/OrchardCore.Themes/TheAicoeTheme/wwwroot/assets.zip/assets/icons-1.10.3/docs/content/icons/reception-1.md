---
title: Reception 1
categories:
  - Communications
tags:
  - reception
  - cellphone
  - mobile
  - carrier
  - network
  - signal
---
