---
title: View list
categories:
  - UI and keyboard
tags:
  - view
  - rearrange
---
