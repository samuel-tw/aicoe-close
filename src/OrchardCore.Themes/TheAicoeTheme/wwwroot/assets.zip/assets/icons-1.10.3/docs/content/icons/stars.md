---
title: Stars
categories:
  - Weather
tags:
  - clear
  - skies
  - night
---
