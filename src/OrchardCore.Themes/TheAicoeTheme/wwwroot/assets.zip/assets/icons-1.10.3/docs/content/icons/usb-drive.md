---
title: USB drive
categories:
  - Devices
tags:
  - thumb-drive
---
