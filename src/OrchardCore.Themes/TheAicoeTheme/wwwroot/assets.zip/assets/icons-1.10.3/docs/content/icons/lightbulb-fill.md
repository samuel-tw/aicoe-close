---
title: Lightbulb fill
categories:
  - Real world
tags:
  - lights
  - lamp
---
