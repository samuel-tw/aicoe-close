---
title: Megaphone
categories:
  - Real world
tags:
  - loudspeaker
  - announcement
---
