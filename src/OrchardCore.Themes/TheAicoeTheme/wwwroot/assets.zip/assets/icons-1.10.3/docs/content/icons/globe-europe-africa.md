---
title: Globe Europe Africa
categories:
  - Geo
tags:
  - geography
  - earth
  - world
  - map
---
