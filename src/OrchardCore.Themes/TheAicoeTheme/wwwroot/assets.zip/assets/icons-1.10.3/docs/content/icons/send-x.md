---
title: Send x
categories:
  - Communications
tags:
  - message
  - sending
  - sent
---
