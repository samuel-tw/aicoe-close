---
title: Sign stop
categories:
  - Transportation
tags:
  - "stop sign"
  - intersection
  - road
  - driving
---
