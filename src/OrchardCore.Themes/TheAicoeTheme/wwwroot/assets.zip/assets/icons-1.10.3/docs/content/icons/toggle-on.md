---
title: Toggle on
categories:
  - Controls
tags:
  - toggle
  - switch
  - checkbox
---
