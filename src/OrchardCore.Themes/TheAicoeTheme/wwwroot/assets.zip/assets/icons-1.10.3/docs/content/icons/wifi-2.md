---
title: Wifi 2
categories:
  - Communications
tags:
  - internet
  - network
  - wireless
---
