---
title: Filetype gif
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
---
