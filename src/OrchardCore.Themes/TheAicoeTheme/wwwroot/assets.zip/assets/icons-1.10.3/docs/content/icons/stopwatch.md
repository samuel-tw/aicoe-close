---
title: Stopwatch
categories:
  - Devices
tags:
  - time
  - timer
  - clock
---
