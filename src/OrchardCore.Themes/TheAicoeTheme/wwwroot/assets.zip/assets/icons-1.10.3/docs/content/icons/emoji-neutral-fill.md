---
title: Emoji neutral fill
categories:
  - Emoji
tags:
  - emoticon
  - expressionless
---
