---
title: Layout text window
categories:
  - Layout
tags:
  - layout
  - columns
---
