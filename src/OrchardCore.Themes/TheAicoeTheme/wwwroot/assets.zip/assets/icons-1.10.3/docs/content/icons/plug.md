---
title: Plug
categories:
  - Real world
tags:
  - power
  - outlet
---
