---
title: Trash
categories:
  - UI and keyboard
tags:
  - trash-can
  - garbage
  - delete
  - remove
---
