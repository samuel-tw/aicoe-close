---
title: Toggle2 off
categories:
  - Controls
tags:
  - toggle
  - switch
  - checkbox
---
