---
title: Mouse2
categories:
  - Devices
tags:
  - mice
  - input
---
