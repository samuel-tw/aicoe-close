---
title: Folder2 open
categories:
  - Files and folders
tags:
  - directory
---
