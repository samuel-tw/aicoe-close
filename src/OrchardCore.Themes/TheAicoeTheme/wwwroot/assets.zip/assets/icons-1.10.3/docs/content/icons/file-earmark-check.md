---
title: File earmark check
categories:
  - Files and folders
tags:
  - doc
  - document
  - check
  - verified
---
