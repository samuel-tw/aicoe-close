---
title: Folder symlink fill
categories:
  - Files and folders
tags:
  - directory
  - symbolic-link
---
