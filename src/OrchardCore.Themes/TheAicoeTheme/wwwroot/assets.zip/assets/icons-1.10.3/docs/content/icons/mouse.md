---
title: Mouse
categories:
  - Devices
tags:
  - mice
  - input
---
