---
title: File x
categories:
  - Files and folders
tags:
  - document
  - remove
  - delete
---
