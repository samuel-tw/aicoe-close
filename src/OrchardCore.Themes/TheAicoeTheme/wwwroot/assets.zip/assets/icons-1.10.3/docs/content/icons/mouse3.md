---
title: Mouse3
categories:
  - Devices
tags:
  - mice
  - input
---
