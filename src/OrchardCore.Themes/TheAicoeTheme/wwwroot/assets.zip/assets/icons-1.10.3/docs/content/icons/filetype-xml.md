---
title: Filetype xml
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
  - code
---
