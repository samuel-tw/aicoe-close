---
title: Sign no left turn
categories:
  - Transportation
tags:
  - road
  - driving
  - directions
---
