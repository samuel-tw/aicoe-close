---
title: Filetype pptx
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
---
