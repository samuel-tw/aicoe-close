---
title: Fast forward fill
categories:
  - Media
tags:
  - audio
  - video
  - av
---
