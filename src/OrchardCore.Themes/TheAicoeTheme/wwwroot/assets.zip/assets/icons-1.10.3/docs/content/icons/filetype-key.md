---
title: Filetype key
categories:
  - Files and folders
tags:
  - file
  - "file type"
  - extension
  - keynote
---
