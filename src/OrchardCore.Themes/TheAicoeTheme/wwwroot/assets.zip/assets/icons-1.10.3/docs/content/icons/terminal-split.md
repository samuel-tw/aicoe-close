---
title: Terminal split
categories:
  - Apps
tags:
  - command-line
  - cli
  - command-prompt
---
